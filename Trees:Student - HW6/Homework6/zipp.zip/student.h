//
//  student.h
//  Homework6
//
//  Created by Jordan Heath on 3/2/16.
//  Copyright © 2016 Jordan Heath. All rights reserved.
//

#ifndef student_h
#define student_h


typedef struct node
{
    char *name_student;
    int number_student;
    
    node(node *a)
    {
        name_student = new char[strlen(a->name_student)+1];
        strcpy(name_student, a->name_student);///creating a deep copy of it
        number_student = a->number_student;// setting the student name equal
    }
    node(char *a, int b)
    {
        name_student = new char[strlen(a)+1];//allocating for the node
        strcpy(name_student, a);
        number_student=b;
    }
    
    
    
    
}Node;

typedef struct treenode//using structs becasue theyre automatically public
{
    //treenode *parent;//points to a parent node
    Node *A,*B,*C;///all three values
    treenode *L,*M1,*M2,*R;// al pointers
    
    treenode()// we got a constructor for creating a completely null tree
    {
        //parent=NULL;
        A=B=C=NULL;
        L=M1=M2=R=NULL;
    }
    
    
    treenode(node *a)//we got this so we can simply add into a nodes child pointer
    {
        B=C=NULL;
        A=new Node(a);//passing in the a value to create the object within
        L=M1=M2=R=NULL;//setting all the pointers to NULL
    }
    
}TreeNode;


template <class T>
class Student {
    
    
public:
    
    
    bool add(char *name, int number);//watch the type return on this one
    void countlevels(ostream &out);
    void calldisplay(ostream &call);
    void Display_in_order(TreeNode *n, ostream &call);
    bool getName(int Student_ID);
    void getLevel(int Student_ID, ostream &call);
    void CountValuesInNode(int Student_ID, ostream &out);
    
    
    void findname(int Student_ID, ostream &call);
    
private:
    TreeNode *Headptr;///I DONT KNOW ABOUT THIS ONE BEING A POINTER
    
};






template <class T> bool Student<T>::add(char *name, int number)
{
    ///first check for duplicates
    
    ///this sets up the whole thinbgn by setting pointers and parents
    TreeNode *n = Headptr;
    TreeNode *P = NULL;
    Node *toAdd = new Node(name,number);
    
    ///run check for doubles
    
    if(n != NULL && !getName(number))
    {
        return false;
    }
    
    if(n == NULL)//this means theres no items in the list
    {
        TreeNode *newnode= new TreeNode(toAdd);
        
        n = newnode;
        if(n)//if allocated
        {
          ///node was allocated
            Headptr=n;
            return true;
            ///RETURN?
        }
    }
    
    
    
    if(n->C != NULL)//this means that the current node has three values in it and we must split it
    {//we split the list
        
        if(P == NULL)
        {//means that it is the node at the top
            //we split the node
            
            P = new TreeNode(n->B);//moving the value up to the parent
            n->B = NULL;///de allocating
            
            P->M1 = new TreeNode(n->C);
            n->C = NULL;
            
            //re assigning the child nodes
            P->M1->L = n->M2;
            P->M1->M1 = n->R;
            n->M2=n->R=NULL;//getting rid of the pointers to the next ones
            
            P->L = n;
            
            ///assign parents
            
            Headptr = P;
            n= P;
        }
        else//if the parent is not null then we want to move the middle value up into the parent
        {        }
        
    }
    
    ///NOW CHECK IF N IS A LEAF
    if(n->L == NULL)//it isnt pointing to anything so it must be a leaf
    {
        if(n->B == NULL)//for if there is one item
        {
            n->B = toAdd;//placing the new pointer in the leaf
            if(n->B->number_student < n->A->number_student)
            {
                std::swap(n->A,n->B);//swap the two pointers
            }
            //return n;
        }
        else if(n->C==NULL)//for if theres two items
        {
            n->C = toAdd;
            if(n->C->number_student < n->B->number_student)
            {
                std::swap(n->B,n->C);//swap the two pointers
            }
            
            if(n->B->number_student < n->A->number_student)
            {
                std::swap(n->A,n->B);//swap the two pointers
            }
            //return n;
            
        }
        
    }
    else//meaning n in internal
    {
        
        
        while(n->L != NULL)//this will stop when we reach a leaf but will split cases that are 3 nodes
        {
            P=n;
            if(toAdd->number_student < n->A->number_student)
            {
                n = n->L;//branch left
            }
            else if(n->B == NULL)
            {
                n= n->M1;//branch right
            }
            else if(toAdd->number_student < n->B->number_student)
            {
                n = n->M1;
            }
            else if(n->C == NULL)
            {
                n=n->M2;
            }
            else if(toAdd->number_student < n->C->number_student)
            {
                n=n->M2;
            }
            else
            {
                n=n->R;
            }
            
            
            if(n->C != NULL)/// THE NODDE IS FULL
            {//this means that
                
                
                if(P->L == n)
                {
                    swap(P->B,P->C);
                    swap(P->A, P->B);//pushes the pointer to A to the right one
                    P->A = n->B;//brings B up to the top
                    n->B = NULL;//frees the pointer
                    
                    
                    swap(P->R,P->M2);//moves the pointer to the right one
                    swap(P->M1,P->M2);//moves the right pointer to the right
                    
                    P->M1 = new TreeNode(n->C);
                    n->C = NULL;
                    
                    
                    P->M1->L = n->M2;
                    n->M2 = NULL;//
                    
                    P->M1->M1 = n->R;
                    n->R = NULL;
                    
                    
                    //the left pointer still remains
                }
                
                
                if(P->M1 == n)//if its the middle pointer
                {
                    swap(P->C, P->B);//switches the null value with the middle
                    P->B=n->B;
                    n->B = NULL;
                    
                    //right has to be null since the node isnt a 3 node
                    swap(P->R, P->M2);
                    
                    P->M2 = new TreeNode(n->C);
                    n->C = NULL;
                    
                    P->M2->L = n->M2;
                    n->M2 = NULL;
                    
                    P->M2->M1 = n->R;
                    n->R = NULL;
                    
                    
                    
                    
                }
                
                if(P->M2 == n)//if its the left one
                {
                    P->C = n->B;
                    n->B = NULL;
                    
                    P->R = new TreeNode(n->C);
                    n->C = NULL;
                    
                    P->R->L = n->M2;
                    n->M2 = NULL;
                    
                    P->R->M1 = n->R;
                    n->R = NULL;
                    
                    
                }
                n= P;//points back up to the parent node so we can further traverse
        }
        
        }

        if(n->B == NULL)//for if there is one item
        {
            n->B = toAdd;//placing the new pointer in the leaf
            if(n->B->number_student < n->A->number_student)
            {
                std::swap(n->A,n->B);//swap the two pointers
            }
            //return n;
        }
        else if(n->C==NULL)//for if theres two items
        {
            n->C = toAdd;
            if(n->C->number_student < n->B->number_student)
            {
                std::swap(n->B,n->C);//swap the two pointers
            }
            
            if(n->B->number_student < n->A->number_student)
            {
                std::swap(n->A,n->B);//swap the two pointers
            }
            //return n;
            
        }
        
        
    }
    
   /// Headptr = n;////i dont know
    
    return true;
}

template <class T> void Student<T>::countlevels(ostream &out)
{
    TreeNode *n=Headptr;
    //starts at 0
    int i=0;
    
    if(!n)
    {
        out << i << endl;
        return;
    }//displays 0 and breaks

    //add one because it isnt numm
    
    while(n)
    {
        i++;//iterates every time
        n=n->L;
    }
    out<<i<<endl;
    
    
}

template <class T> bool Student<T>::getName(int Student_ID)
{
    TreeNode *n = Headptr;
    
    //this is going to go through to find out if the name is actually being used in the data set already... branches are given for certain conditions
    while(n)
    {
        if(Student_ID < n->A->number_student)
        {
            n= n->L;
        }
        else if(Student_ID == n->A->number_student)
        {
            return false;
        }
        else if(Student_ID > n->A->number_student && !(n->B))
        {
            n=n->M1;
        }
        else if(Student_ID > n->A->number_student && Student_ID < n->B->number_student)
        {
            n=n->M1;
        }
        else if(Student_ID == n->B->number_student)
        {
            return false;
        }
        else if(Student_ID > n->B->number_student && !(n->C))
        {
            n=n->M2;
        }
        else if(Student_ID > n->B->number_student && Student_ID < n->C->number_student)
        {
            n=n->M1;
        }
        else if(Student_ID == n->C->number_student)
        {
            return false;
        }
        else
        {
            n=n->R;
        }
        
    }
    
    return true;
    
    
}

template <class T> void Student<T>::Display_in_order(TreeNode *n, ostream &call)
{///FOR THIS IM GOING TO USE RECURRSION
    
    if(n->L)
    {
        Display_in_order(n->L, call);//goes all the way to the rightmost value
    }
    
    
    call << n->A->name_student <<',' << n->A->number_student << ';';//prints the A value
    
    
    if(n->M1)
    {
        Display_in_order(n->M1, call);///call going to the M1 pointer
    }
    
    if(n->B)
    {
    call << n->B->name_student <<',' << n->B->number_student << ';';//prints B value
        
    if(n->M2)
    {
        Display_in_order(n->M2, call);
    }
        
    }
    
    if(n->C)
    {
    call << n->C->name_student <<',' << n->C->number_student << ';';
    
    
    if(n->R)
    {
        Display_in_order(n->R, call);//
    }
    }
    
    
}

template <class T> void Student<T>::getLevel(int Student_ID, ostream &call)
{
    
    int level = 0;
    
    TreeNode *n = Headptr;
    
    if(!n)
    {//this means that the node we wanna search is NULL
        call << -1<<endl;
        return;
    }
    
    
    while(n)
    {
        
        if(Student_ID < n->A->number_student)
        {
            level++;//iterate an move to the next node
            n= n->L;
        }
        else if(Student_ID == n->A->number_student)
        {
            break;//its found break out of thos statement
        }
        else if(Student_ID > n->A->number_student && !(n->B))
        {
            level++;
            n=n->M1;
        }
        else if(Student_ID > n->A->number_student && Student_ID < n->B->number_student)
        {
            level++;
            n=n->M1;
        }
        else if(Student_ID == n->B->number_student)
        {
            break;
        }
        else if(Student_ID > n->B->number_student && !(n->C))
        {
            level++;
            n=n->M2;
        }
        else if(Student_ID > n->B->number_student && Student_ID < n->C->number_student)
        {
            level++;
            n=n->M1;
        }
        else if(Student_ID == n->C->number_student)
        {
            break;
        }
        else
        {
            level++;
            n=n->R;
        }
    }

    if(!n)
    {
        call<<-1<<endl;
        return;
    }
    else{
        call<<level<<endl;
    }
    
    
    
    
    
    
    
}


template <class T> void Student<T>::CountValuesInNode(int Student_ID, ostream &out)
{
    
    ///search for the node with the value in it
    TreeNode *n=Headptr;
    
    while(n)
    {
        
        if(Student_ID < n->A->number_student)
        {
            n= n->L;
        }
        else if(Student_ID == n->A->number_student)
        {
            break;
        }
        else if(Student_ID > n->A->number_student && !(n->B))
        {
            n=n->M1;
        }
        else if(Student_ID > n->A->number_student && Student_ID < n->B->number_student)
        {
            n=n->M1;
        }
        else if(Student_ID == n->B->number_student)
        {
            break;
        }
        else if(Student_ID > n->B->number_student && !(n->C))
        {
            n=n->M2;
        }
        else if(Student_ID > n->B->number_student && Student_ID < n->C->number_student)
        {
            n=n->M1;
        }
        else if(Student_ID == n->C->number_student)
        {
            break;
        }
        else
        {
            n=n->R;
        }
    }
    
    if(n->C)
    {
        out << 3 << endl;
    }
    else if(n->B)
    {
        out << 2 << endl;
    }
    else if (n->A)
    {
        out << 1 << endl;
    }
    else
    {
        out << -1 << endl;
    }
}


/*
 
 
 
 if(P->L == n)//this means that it is the value to the left
 {
 if(n->parent->B != NULL)//were going to push it to the right one
 {
 swap(n->parent->B, n->parent->C);///a simple push
 swap(n->parent->A, n->parent->B);//B is already null so now were going to place the values in
 n->parent->A = n->B;
 n->B=NULL;//de allocation
 
 //push the pointers to the left
 n->parent->R = n->parent->M2;
 n->parent->M2 = n->parent->M1;
 
 /////if problem arises check here
 n->parent->L->parent = n->parent;
 
 
 n->parent->M1 = new TreeNode(n->C);
 n->parent->M1->parent = n->parent;
 n->C=NULL;
 
 
 n->parent->M1->L = n->M2;
 n->parent->M1->M1 = n->R;
 
 
 n->M2=NULL;
 n->R=NULL;///////
 }
 else//this means there is only one item in the array
 {
 ///what goes here
 swap(n->parent->A, n->parent->B);
 n->parent->A = n->B;//moving the middle value up to the top
 n->B = NULL;
 
 
 n->parent->M2= n->parent->M1;/// this pushed the higher value to the right
 
 n->parent->M1 = new TreeNode(n->C);
 n->C = NULL;
 n->parent->M1->parent = n->parent;
 
 
 
 n->parent->M1->L = n->M2;
 n->parent->M1->M1 = n->R;
 
 
 n->M2=n->R=NULL;
 
 }
 
 
 }
 else if(n->parent->M1 == n)
 {
 //this means that it s the middle value that needs to go up
 if(n->parent->B == NULL)
 {
 n->parent->B = n->B;
 n->B = NULL;//freeing the pointer
 n->parent->M2 = new TreeNode(n->C);
 n->C = NULL;
 n->parent->M2->L = n->M2;
 n->parent->M2->M1 = n->R;
 
 n->M2=n->R=NULL;
 n->parent->M2->parent= n->parent;
 
 }
 else
 {
 swap(n->parent->B, n->parent->C);
 n->parent->B = n->B;
 n->B=NULL;
 n->parent->R = n->parent->M2;
 delete n->parent->M2;//makes it NULL;
 n->parent->M2 = new TreeNode(n->C);
 n->C=NULL;
 n->parent->M2->parent=n->parent;
 
 
 n->parent->M1->L = n->L;
 n->parent->M1->M1 = n->M1;
 n->parent->M2->L = n->M2;
 n->parent->M2->M1 = n->R;
 
 }
 
 }
 else if(n->parent->M2 == n)
 {
 n->parent->C = n->B;//moving the value up
 n->B = NULL;//getting rid of that allocation
 n->parent->R = new TreeNode(n->C);
 n->C = NULL;
 
 n->parent->R->parent=n->parent;///assigning a parent node for these
 
 n->parent->R->L = n->M2;
 n->parent->R->M1 = n->R;
 
 
 n->M2=NULL;
 n->R=NULL;
 
 }
 n=n->parent;
 

 
 
 */

template <class T> void Student<T>:: findname(int Student_ID, ostream &call)
{
   
    TreeNode *n = Headptr;
    while(n)
    {
        
        if(Student_ID < n->A->number_student)
        {
            n= n->L;
        }
        else if(Student_ID == n->A->number_student)
        {
            call << n->A->name_student << endl;
            return;
        }
        else if(Student_ID > n->A->number_student && !(n->B))
        {
            n=n->M1;
        }
        else if(Student_ID > n->A->number_student && Student_ID < n->B->number_student)
        {
            n=n->M1;
        }
        else if(Student_ID == n->B->number_student)
        {
            call << n->B->name_student << endl;
            return;
        }
        else if(Student_ID > n->B->number_student && !(n->C))
        {
            n=n->M2;
        }
        else if(Student_ID > n->B->number_student && Student_ID < n->C->number_student)
        {
            n=n->M2;
        }
        else if(Student_ID == n->C->number_student)
        {
            call << n->A->name_student << endl;
            return;
        }
        else
        {
            n=n->R;
        }
    }
    call << "(student not found)" << endl;
    
}



template <class T> void Student<T>:: calldisplay(ostream &call)
{
    Display_in_order(Headptr, call);
    call << endl;
}



#endif /* student_h */
